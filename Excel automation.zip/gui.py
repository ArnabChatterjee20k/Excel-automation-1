from tkinter import Tk, Label, Button, filedialog, messagebox
import pandas as pd
import openpyxl
import xlsxwriter

class Auto:
    def __init__(self,myWindowObject):
        print("Initialized")
        # GUI BUTTONS
        print("Creating GUI.....")
        self.button_select_excel_sheet = Button(myWindowObject, text="Select Input Excel File",
                                                command=self.read, bg="white")
        self.button_generate_results = Button(myWindowObject, text="Generate Output",
                                              bg="white")

        # Placing my Label into window
        self.button_select_excel_sheet.place(x=20, y=20, height=80, width=400)
        self.button_generate_results.place(x=145, y=130, height=40, width=160)
    def read(self):
       try:
            filename = filedialog.askopenfilename()
            self.input_data = pd.read_excel(filename)
            self.button_select_excel_sheet["bg"] = "green"
            self.button_generate_results.configure(command=lambda:self.generate())

       except:
           print("Error in reading")
           self.button_select_excel_sheet["bg"] = "red"
    def export(self,data):

        # Present in input ['CABLE_TAG', 'VOLT_GRADE', 'TYPE', 'CORExSIZE', 'TOTAL_LENGTH', 'AREA','ALLOCATED DRUM-NUMBER']

        # out_header=["Is.","Area","MR POS","CABLE TAG NUMBER","Voltage grade","Cabel Size(sq.mm)","Cable Length(m)",
        # "Total Cable Length","TECNIMONT DRUM NUMBER","Vendor DruM No.","Drum Length","Available Spare","Remarks"]

        ## loading the xlsx file

        ## sheet1("DRUM_SCHEDULE")

        data=data.sort_values(["ALLOCATED DRUM-NUMBER","TOTAL_LENGTH"],ascending=False)### sorting the data and  storing it in data
        try:
            ###  making  columns and adding datas by usinhg the headers of input file
            #### Left hand values are headers of output file and Right one is of input
            ### schedule
            file_data = {
                "Is": range(1, len(data["AREA"]) + 1),
                "Area": data["AREA"],
                "MR POS": " ",
                "TAG NUMBERLINE": data["CABLE_TAG"],
                "Voltage grade": data['VOLT_GRADE'],
                "Cabel Size(sq.mm)": data['CORExSIZE'],
                "Cable Length(m)": data['TOTAL_LENGTH'],
                "Total Cable Length": "",
                "TECNIMONT DRUM NUMBER": data["ALLOCATED DRUM-NUMBER"],
                "Vendor DruM No.": "",
                "Drum Length": "",
                "AVAILABLE SPARE": "",
                "REMARKS": ""
            }
            ## summary
            file_data1 = {

                "MR POS": " ",
                "Voltage grade": data['VOLT_GRADE'],
                "Cabel Size(sq.mm)": data['CORExSIZE'],
                "TECNIMONT DRUM NUMBER": data["ALLOCATED DRUM-NUMBER"],
                "Vendor DruM No.": "",
                "Drum Length": "",
                "REMARKS": "",
                "not usable": data['TOTAL_LENGTH']
                ##later in formatting it will be deleted. It is used for values of drum length
            }


            df=pd.DataFrame(file_data)
            df1=pd.DataFrame(file_data1)
            with pd.ExcelWriter("Output4.xlsx", engine="xlsxwriter") as writer:
                df.to_excel(writer,index=False,startrow=5,sheet_name="DRUM_SCHEDULE")###start row is 5 to give space for header
                df1.to_excel(writer, index=False, startrow=5,sheet_name="DRUM_SUMMARY")  ###start row is 5 to give space for header
            #### formatting the output file and doing the calcuations and mergings


            ### formatting schedule

            wb = openpyxl.load_workbook("Output4.xlsx")
            sheet = wb["DRUM_SCHEDULE"]
            sheet.column_dimensions["B"].width = 30
            sheet.column_dimensions["C"].width = 30
            sheet.column_dimensions["D"].width = 30
            sheet.column_dimensions["E"].width = 30
            sheet.column_dimensions["F"].width = 30
            sheet.column_dimensions["H"].width = 30
            sheet.column_dimensions["G"].width = 20
            sheet.column_dimensions["I"].width = 30
            sheet.column_dimensions["J"].width = 20
            sheet.column_dimensions["L"].width = 30

            sheet.merge_cells("A1:C2")
            sheet["A1"].value="Date of Revision XX/XX/2021"
            sheet.merge_cells("A3:C5")
            sheet["A3"].value="DOCUMENT  N°:XXXX-NN-LK-xxxxxxx"
            sheet.merge_cells("D1:E5")
            sheet["D1"].value="ELECTRICAL DRUM SCHEDULE"
            sheet.merge_cells("F1:H2")
            sheet["F1"]="CLIENT DOCUMENT NO.xxxxxxxx"
            sheet.merge_cells("F3:I5")
            sheet["F3"].value="Rev01"

            H = []
            for i in range(7, (sheet.max_row) + 1):
                H.append(sheet.cell(row=i, column=9).value)

            length = len(H)
            index = []
            for i in H:
                index.append(H.index(i))
                index.append(~H[::-1].index(i) + length)
                if index[0] > index[-1]:
                    index[0], index[-1] = index[-1], index[0]

                sheet.merge_cells(start_column=8, start_row=index[0] + 7, end_row=index[-1] + 7,
                                  end_column=8)  ####G column
                sheet.merge_cells(start_column=11, start_row=index[0] + 7, end_row=index[-1] + 7,
                                  end_column=11)  ## J column
                sheet.merge_cells(start_column=12, start_row=index[0] + 7, end_row=index[-1] + 7,
                                  end_column=12)  ## K column
                sheet[f"H{index[0] + 7}"] = f"=SUM(G{index[0] + 7}:G{index[-1] + 7})"
                sheet[f"K{index[0] + 7}"] = f"=SUM(G{index[0] + 7}:G{index[-1] + 7})"
                sheet[f"L{index[0] + 7}"] = f"=(H{index[0] + 7}:H{index[-1] + 7})-(K{index[0] + 7}:K{index[-1] + 7})"
                index.clear()
            wb.save("Output4.xlsx")



            wb = openpyxl.load_workbook("Output4.xlsx")
            sheet = wb["DRUM_SUMMARY"]
            sheet.column_dimensions["A"].width = 30
            sheet.column_dimensions["B"].width = 30
            sheet.column_dimensions["C"].width = 30
            sheet.column_dimensions["D"].width = 30
            sheet.column_dimensions["E"].width = 30
            sheet.column_dimensions["B"].width = 30
            sheet.column_dimensions["C"].width = 30
            sheet.column_dimensions["D"].width = 30
            sheet.column_dimensions["E"].width = 30
            sheet.column_dimensions["F"].width = 30
            sheet.column_dimensions["G"].width = 30
            sheet.column_dimensions["H"].width = 30

            sheet.merge_cells("A1:C2")
            sheet["A1"].value = "Date of Revision XX/XX/2021"
            sheet.merge_cells("A3:C5")
            sheet["A3"].value = "DOCUMENT  N°:XXXX-NN-LK-xxxxxxx"
            sheet.merge_cells("D1:E5")
            sheet["D1"].value = "ELECTRICAL DRUM SUMMARY"
            sheet.merge_cells("F1:H2")
            sheet["F1"] = "CLIENT DOCUMENT NO.xxxxxxxx"
            sheet.merge_cells("F3:I5")
            sheet["F3"].value = "Rev01"

            index = []
            length = len(H)
            sl=len(set(H))
            for i in H:
                index.append(H.index(i))
                index.append(~H[::-1].index(i) + length)
                if index[0] > index[-1]:
                    index[0], index[-1] = index[-1], index[0]
                sheet[f"F{index[0] + 7}"] = f"=SUM(H{index[0] + 7}:H{index[-1] + 7})"

                for j in range(1,7):
                    sheet.merge_cells(start_column=j, start_row=index[0] + 7, end_row=index[-1] + 7,
                                      end_column=j)  ####G column
                index.clear()
            wb.save("Output4.xlsx")
        except:
            print("Export error")

    def generate(self):
        try:
            data = pd.DataFrame(self.input_data)
            self.export(data)
            messagebox.showinfo("Report Generated", "Output4  has been created successfully")
            myWindowObject.destroy()

        except:
            print("Error while generating results...")



#Initiating window object
myWindowObject = Tk()
#Setting attributes to window
myWindowObject.title("Saurabh Sinha - Tecnimount")
myWindowObject.geometry("440x200")
myWindowObject.configure(bg='#456275')
#Passing my window object to my class
myClassObject = Auto(myWindowObject)

#main loop
myWindowObject.mainloop()